# forecast.py
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("grocery_prices.csv")

# Filter for one item and one store
item = "Milk"
store = "Store A"
subset = df[(df['item'] == item) & (df['store'] == store)]

# Convert 'date' column to datetime
subset['date'] = pd.to_datetime(subset['date'])

# Create a numeric column for days since first date
subset['days'] = (subset['date'] - subset['date'].min()).dt.days

# Fit a linear regression line to price over time
coeffs = np.polyfit(subset['days'], subset['price'], deg=1)
trend = np.poly1d(coeffs)

# Plot the actual prices and the trend line
plt.figure(figsize=(10, 5))
plt.plot(subset['date'], subset['price'], label='Actual Price', marker='o')
plt.plot(subset['date'], trend(subset['days']), color='red', label='Trend Line (Forecast)')
plt.title(f'{item} Price Trend - {store}')
plt.xlabel('Date')
plt.ylabel('Price ($)')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

#equation for your report
print(f"Forecast equation: price = {coeffs[0]:.4f} * days + {coeffs[1]:.2f}")