import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv("grocery_prices.csv")

item = "Milk"
store = "Store A"
subset = df[(df['item'] == item) & (df['store'] == store)]

subset['date'] = pd.to_datetime(subset['date'])

subset['days'] = (subset['date'] - subset['date'].min()).dt.days

coeffs = np.polyfit(subset['days'], subset['price'], deg=1)
trend = np.poly1d(coeffs)

plt.figure(figsize=(10, 5))
plt.plot(subset['date'], subset['price'], label='Actual Price', marker='o')
plt.plot(subset['date'], trend(subset['days']), color='red', label='Trend Line (Forecast)')
plt.title(f'{item} Price Trend - {store}')
plt.xlabel('Date')
plt.ylabel('Price ($)')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()



print(f"Forecast equation: price = {coeffs[0]:.4f} * days + {coeffs[1]:.2f}")

future_days = np.arange(subset['days'].max() + 1, subset['days'].max() + 31)
future_dates = pd.date_range(start=subset['date'].max() + pd.Timedelta(days=1), periods=30)

future_prices = trend(future_days)

forecast_df = pd.DataFrame({'date': future_dates, 'predicted_price': future_prices})
print("Price Predictions for Next 30 Days:")
print(forecast_df)

plt.plot(future_dates, future_prices, color='green', linestyle='--', label='Predicted Future Prices')
plt.legend()
plt.show()