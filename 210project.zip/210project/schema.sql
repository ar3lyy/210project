-- items table
CREATE TABLE items (
    item_id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    category VARCHAR(50)
);

-- stores table
CREATE TABLE stores (
    store_id SERIAL PRIMARY KEY,
    name VARCHAR(100)
);

-- prices table
CREATE TABLE prices (
    price_id SERIAL PRIMARY KEY,
    item_id INT REFERENCES items(item_id),
    store_id INT REFERENCES stores(store_id),
    price NUMERIC,
    date DATE
);