import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("grocery_prices.csv")
df['date'] = pd.to_datetime(df['date'])

print("Preview:")
print(df.head())
print("Summary Stats (All Items):")
print(df.groupby('item')['price'].describe())

print("Store Averages:")
print(df.groupby(['store', 'item'])['price'].mean().unstack().round(2))

print("Price Volatility (Std Dev):")
print(df.groupby('item')['price'].std().round(2))

# Visualization 1: Average Price per Item (all stores combined)
plt.figure(figsize=(8, 4))
sns.barplot(data=df, x='item', y='price', estimator='mean', errorbar=None)
plt.title("Average Price per Item")
plt.ylabel("Average Price ($)")
plt.tight_layout()
plt.show()

#Visualization 2: Line plot for each item across time (all stores)
plt.figure(figsize=(10, 6))
sns.lineplot(data=df, x='date', y='price', hue='item')
plt.title("Price Trends for All Items Over Time")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

#Visualization 3: Price comparison by item across stores
plt.figure(figsize=(10, 6))
sns.boxplot(data=df, x='item', y='price', hue='store')
plt.title("Price Distribution per Item by Store")
plt.tight_layout()
plt.show()


# drop in price
df_sorted = df.sort_values(['item', 'store', 'date']).copy()
df_sorted['prev_price'] = df_sorted.groupby(['item', 'store'])['price'].shift(1)
df_sorted['price_change'] = df_sorted['price'] - df_sorted['prev_price']
df_sorted['drop'] = df_sorted['price_change'] < 0

drop_summary = (
    df_sorted[df_sorted['drop']]
    .groupby(['item', 'store'])
    .agg(
        drops=('drop', 'sum'),
        avg_drop_pct=('price_change', lambda x: (x / df_sorted.loc[x.index, 'prev_price']).mean())
    )
    .reset_index()
)
print(drop_summary)

# Average price per item by store
plt.figure(figsize=(10, 6))
sns.barplot(data=df, x='item', y='price', hue='store', estimator='mean', errorbar=None)
plt.title('Average Price per Item by Store')
plt.xlabel('Item')
plt.ylabel('Average Price ($)')
plt.legend(title='Store')
plt.tight_layout()
plt.savefig("avg_price_per_item_by_store.png")
plt.show()



items = df['item'].unique()
for item in items:
    subset = df[df['item'] == item]
    plt.figure(figsize=(10, 5))
    sns.lineplot(data=subset, x='date', y='price', hue='store')
    plt.title(f'Price Trend Over Time: {item}')
    plt.xlabel('Date')
    plt.ylabel('Price ($)')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(f"price_trend_{item.lower()}.png")
    plt.close() 





summary_stats = df.groupby('item')['price'].describe()
summary_stats.to_csv("item_price_summary.csv")