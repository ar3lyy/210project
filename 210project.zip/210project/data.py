import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Create fake dataset
start_date = datetime(2024, 1, 1)
end_date = datetime(2024, 6, 30)
dates = pd.date_range(start_date, end_date)

items = ['Milk', 'Eggs', 'Bread', 'Apples', 'Chicken']
stores = ['Store A', 'Store B', 'Store C']
categories = {'Milk': 'Dairy', 'Eggs': 'Dairy', 'Bread': 'Bakery', 'Apples': 'Produce', 'Chicken': 'Meat'}

data = []

np.random.seed(42)

for item in items:
    for store in stores:
        base_price = np.random.uniform(2, 10)
        for date in dates:
            fluctuation = np.random.normal(0, 0.2)
            price = round(base_price + fluctuation, 2)
            price = max(0.5, price)
            data.append({
                'date': date,
                'item': item,
                'category': categories[item],
                'store': store,
                'price': price
            })

df = pd.DataFrame(data)
df.to_csv("grocery_prices.csv", index=False)
print("✅ grocery_prices.csv successfully created!")
